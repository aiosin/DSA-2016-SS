package de.unistuttgart.dsass2016.ex00.p1;

public class Calculator implements ICalculator {


}