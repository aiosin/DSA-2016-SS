package de.unistuttgart.dsass2016.ex01.p3;


public class Stack<T> implements IStack<T> {
	

}
