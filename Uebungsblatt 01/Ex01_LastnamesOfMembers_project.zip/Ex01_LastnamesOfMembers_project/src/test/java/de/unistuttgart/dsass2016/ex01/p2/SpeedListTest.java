package de.unistuttgart.dsass2016.ex01.p2;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;

import de.unistuttgart.dsass2016.ex01.p2.SpeedList;

public class SpeedListTest {


}
